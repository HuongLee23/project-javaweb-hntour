/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Admin
 */
public class Quater {

    private double quater1;
    private double quater2;
    private double quater3;
    private double quater4;

    public Quater() {
    }

    public Quater(double quater1, double quater2, double quater3, double quater4) {
        this.quater1 = quater1;
        this.quater2 = quater2;
        this.quater3 = quater3;
        this.quater4 = quater4;
    }

    public double getQuater1() {
        return quater1;
    }

    public void setQuater1(double quater1) {
        this.quater1 = quater1;
    }

    public double getQuater2() {
        return quater2;
    }

    public void setQuater2(double quater2) {
        this.quater2 = quater2;
    }

    public double getQuater3() {
        return quater3;
    }

    public void setQuater3(double quater3) {
        this.quater3 = quater3;
    }

    public double getQuater4() {
        return quater4;
    }

    public void setQuater4(double quater4) {
        this.quater4 = quater4;
    }
}
