/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Admin
 */
public class TotalInvoiceOfCategory {
    private double totalCate1;
    private double totalCate2;
    private double totalCate3;
    private double totalCate4;

    public TotalInvoiceOfCategory() {
    }

    public TotalInvoiceOfCategory(double totalCate1, double totalCate2, double totalCate3, double totalCate4) {
        this.totalCate1 = totalCate1;
        this.totalCate2 = totalCate2;
        this.totalCate3 = totalCate3;
        this.totalCate4 = totalCate4;
    }

    public double getTotalCate1() {
        return totalCate1;
    }

    public void setTotalCate1(double totalCate1) {
        this.totalCate1 = totalCate1;
    }

    public double getTotalCate2() {
        return totalCate2;
    }

    public void setTotalCate2(double totalCate2) {
        this.totalCate2 = totalCate2;
    }

    public double getTotalCate3() {
        return totalCate3;
    }

    public void setTotalCate3(double totalCate3) {
        this.totalCate3 = totalCate3;
    }

    public double getTotalCate4() {
        return totalCate4;
    }

    public void setTotalCate4(double totalCate4) {
        this.totalCate4 = totalCate4;
    }
    
    
    
    

}
